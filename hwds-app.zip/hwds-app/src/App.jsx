import { useState, useMemo, useEffect, useRef } from "react";
import { initializeApp } from "firebase/app";
import {
  getFirestore, collection, doc, onSnapshot,
  setDoc, deleteDoc, addDoc, updateDoc, serverTimestamp,
  enableIndexedDbPersistence
} from "firebase/firestore";
import {
  getAuth, signInWithEmailAndPassword, signOut,
  onAuthStateChanged, createUserWithEmailAndPassword
} from "firebase/auth";

// ─────────────────────────────────────────────────────────────
// 🔥 FIREBASE CONFIG
// ─────────────────────────────────────────────────────────────
const firebaseConfig = {
  apiKey:            "AIzaSyCJBHnqEJKiXpMvbpwLuT-_NIioJv3j5TI",
  authDomain:        "hosnywaterdrinkshop.firebaseapp.com",
  projectId:         "hosnywaterdrinkshop",
  storageBucket:     "hosnywaterdrinkshop.appspot.com",
  messagingSenderId: "884749368236",
  appId:             "1:884749368236:web:efdfc7e52100590f441809",
};

// ── Init Firebase ─────────────────────────────────────────────
const firebaseApp = initializeApp(firebaseConfig);
const db          = getFirestore(firebaseApp);
const auth        = getAuth(firebaseApp);

// ── Offline persistence ───────────────────────────────────────
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === "failed-precondition") console.warn("Multiple tabs open");
  else if (err.code === "unimplemented")  console.warn("Offline not supported");
});

// ─────────────────────────────────────────────────────────────
// OWNER EMAIL — only this email gets full owner access
// ─────────────────────────────────────────────────────────────
const OWNER_EMAIL = "evansopoku2019@gmail.com";

// ─────────────────────────────────────────────────────────────
// LOGIN SCREEN
// ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [showPass, setShowPass] = useState(false);

  async function handleLogin() {
    if (!email || !password) { setError("Please enter email and password"); return; }
    setLoading(true); setError("");
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (e) {
      setError(
        e.code === "auth/user-not-found"   ? "Email not found. Contact the owner." :
        e.code === "auth/wrong-password"   ? "Wrong password. Try again." :
        e.code === "auth/invalid-email"    ? "Invalid email address." :
        e.code === "auth/too-many-requests"? "Too many attempts. Try again later." :
        "Login failed. Check your email and password."
      );
      setLoading(false);
    }
  }

  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(135deg,#0f172a 0%,#1e3a5f 100%)", display:"flex", alignItems:"center", justifyContent:"center", padding:20, fontFamily:"'DM Sans',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;800&display=swap" rel="stylesheet" />
      <div style={{ background:"#fff", borderRadius:24, padding:"36px 32px", width:"100%", maxWidth:380, boxShadow:"0 32px 80px #00000040" }}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:28 }}>
          <div style={{ fontSize:48, marginBottom:8 }}>🏪</div>
          <div style={{ fontSize:20, fontWeight:900, color:"#0f172a" }}>HWDS</div>
          <div style={{ fontSize:13, color:"#64748b", fontWeight:600, marginTop:2 }}>Hosny Water & Drink Shop</div>
          <div style={{ fontSize:11, color:"#94a3b8", marginTop:4 }}>Pack Management System</div>
        </div>

        {/* Form */}
        <div style={{ marginBottom:14 }}>
          <label style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", display:"block", marginBottom:5 }}>Email</label>
          <input
            type="email" placeholder="Enter your email"
            value={email} onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleLogin()}
            style={{ width:"100%", background:"#f8fafc", border:"1.5px solid #e2e8f0", borderRadius:10, padding:"11px 14px", fontFamily:"inherit", fontSize:14, outline:"none", color:"#0f172a" }}
          />
        </div>
        <div style={{ marginBottom:20, position:"relative" }}>
          <label style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", display:"block", marginBottom:5 }}>Password</label>
          <input
            type={showPass ? "text" : "password"} placeholder="Enter your password"
            value={password} onChange={e => setPassword(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleLogin()}
            style={{ width:"100%", background:"#f8fafc", border:"1.5px solid #e2e8f0", borderRadius:10, padding:"11px 44px 11px 14px", fontFamily:"inherit", fontSize:14, outline:"none", color:"#0f172a" }}
          />
          <button onClick={() => setShowPass(p => !p)} style={{ position:"absolute", right:12, top:32, background:"none", border:"none", cursor:"pointer", fontSize:18, color:"#94a3b8" }}>
            {showPass ? "🙈" : "👁️"}
          </button>
        </div>

        {error && (
          <div style={{ background:"#fef2f2", border:"1.5px solid #fecaca", borderRadius:10, padding:"10px 14px", fontSize:13, color:"#dc2626", fontWeight:600, marginBottom:14 }}>
            ⚠️ {error}
          </div>
        )}

        <button
          onClick={handleLogin} disabled={loading}
          style={{ width:"100%", background:loading?"#94a3b8":"linear-gradient(135deg,#1d4ed8,#2563eb)", color:"#fff", border:"none", borderRadius:12, padding:"13px 0", fontSize:15, fontWeight:800, cursor:loading?"not-allowed":"pointer", fontFamily:"inherit", transition:"all .2s" }}
        >
          {loading ? "Signing in…" : "Sign In →"}
        </button>

        <div style={{ textAlign:"center", marginTop:20, fontSize:12, color:"#94a3b8" }}>
          🔒 Secured by Firebase Authentication
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// ADD SELLER MODAL (Owner only)
// ─────────────────────────────────────────────────────────────
function AddSellerModal({ onClose, onAdded }) {
  const [email, setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [name, setName]      = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError]    = useState("");

  async function handleAdd() {
    if (!email || !password || !name) { setError("Fill in all fields"); return; }
    if (password.length < 6) { setError("Password must be at least 6 characters"); return; }
    setLoading(true); setError("");
    try {
      // Create seller account in Firebase Auth
      await createUserWithEmailAndPassword(auth, email.trim(), password);
      // Save seller name to Firestore
      await setDoc(doc(db, "sellers", email.trim()), { name, email: email.trim(), role: "seller", createdAt: serverTimestamp() });
      onAdded(name);
      onClose();
    } catch (e) {
      setError(
        e.code === "auth/email-already-in-use" ? "This email already has an account." :
        e.code === "auth/invalid-email"        ? "Invalid email address." :
        "Failed to create seller: " + e.message
      );
      setLoading(false);
    }
  }

  return (
    <div style={{ position:"fixed", inset:0, background:"#00000060", zIndex:600, display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}>
      <div style={{ background:"#fff", borderRadius:20, padding:28, width:400, maxWidth:"100%", boxShadow:"0 32px 80px #00000025" }}>
        <div style={{ fontSize:17, fontWeight:800, marginBottom:20 }}>👤 Add New Seller</div>
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          <div>
            <label style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", display:"block", marginBottom:5 }}>Seller Name</label>
            <input type="text" placeholder="e.g. Ama, Kofi…" value={name} onChange={e => setName(e.target.value)} style={{ width:"100%", background:"#f8fafc", border:"1.5px solid #e2e8f0", borderRadius:10, padding:"10px 13px", fontFamily:"inherit", fontSize:13, outline:"none" }} />
          </div>
          <div>
            <label style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", display:"block", marginBottom:5 }}>Seller Email</label>
            <input type="email" placeholder="seller@gmail.com" value={email} onChange={e => setEmail(e.target.value)} style={{ width:"100%", background:"#f8fafc", border:"1.5px solid #e2e8f0", borderRadius:10, padding:"10px 13px", fontFamily:"inherit", fontSize:13, outline:"none" }} />
          </div>
          <div>
            <label style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", display:"block", marginBottom:5 }}>Password</label>
            <input type="password" placeholder="Min 6 characters" value={password} onChange={e => setPassword(e.target.value)} style={{ width:"100%", background:"#f8fafc", border:"1.5px solid #e2e8f0", borderRadius:10, padding:"10px 13px", fontFamily:"inherit", fontSize:13, outline:"none" }} />
          </div>
        </div>
        {error && <div style={{ background:"#fef2f2", border:"1.5px solid #fecaca", borderRadius:10, padding:"10px 14px", fontSize:13, color:"#dc2626", fontWeight:600, marginTop:12 }}>⚠️ {error}</div>}
        <div style={{ display:"flex", gap:10, marginTop:20, justifyContent:"flex-end" }}>
          <button onClick={onClose} style={{ background:"#fff", border:"1.5px solid #e2e8f0", color:"#374151", borderRadius:10, padding:"8px 16px", fontFamily:"inherit", fontWeight:700, cursor:"pointer", fontSize:13 }}>Cancel</button>
          <button onClick={handleAdd} disabled={loading} style={{ background:"#1d4ed8", color:"#fff", border:"none", borderRadius:10, padding:"8px 20px", fontFamily:"inherit", fontWeight:700, cursor:"pointer", fontSize:13 }}>
            {loading ? "Creating…" : "Create Seller Account"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Helpers ───────────────────────────────────────────────────
const GHS       = (n) => `GH₵ ${Number(n).toFixed(2)}`;
const todayStr  = () => new Date().toISOString().slice(0, 10);
const nowStr    = () => new Date().toLocaleTimeString("en-GH", { hour: "2-digit", minute: "2-digit" });
const dateFmt   = (d) => new Date(d).toLocaleDateString("en-GH", { day: "2-digit", month: "short", year: "numeric" });
const CATS      = ["All", "Water", "Soft Drink", "Energy Drink", "Juice", "Other"];

// ─────────────────────────────────────────────────────────────
// APP
// ─────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser]         = useState(undefined);
  const [userRole, setUserRole] = useState(null);
  const [userName, setUserName] = useState("");
  const [page, setPage]         = useState("dashboard");
  const [drinks, setDrinks]     = useState([]);
  const [sales, setSales]       = useState([]);
  const [debts, setDebts]       = useState([]);
  const [sellersList, setSellersList] = useState([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [loading, setLoading]   = useState(true);
  const [showAddSeller, setShowAddSeller] = useState(false);

  // UI
  const [toast, setToast]       = useState(null);
  const [modal, setModal]       = useState(null);
  const [catFilter, setCatFilter] = useState("All");
  const [searchQ, setSearchQ]   = useState("");
  const [reportPeriod, setReportPeriod] = useState("today");
  const [dForm, setDForm]       = useState({});
  const [editId, setEditId]     = useState(null);
  const [saleForm, setSaleForm] = useState({ drinkId: "", packs: 1, seller: "", customer: "", paid: true });
  const [debtForm, setDebtForm] = useState({ customer: "", drinkId: "", packs: 1, seller: "" });
  const fileRef = useRef(null);

  const showToast = (msg, type = "ok") => { setToast({ msg, type }); setTimeout(() => setToast(null), 3500); };
  const isOwner = userRole === "owner";

  // ── Auth state ────────────────────────────────────────────────
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        if (firebaseUser.email === OWNER_EMAIL) {
          setUserRole("owner"); setUserName("Owner"); setPage("dashboard");
        } else {
          setUserRole("seller");
          const sellerDoc = await new Promise(resolve => {
            const u = onSnapshot(doc(db, "sellers", firebaseUser.email), snap => { u(); resolve(snap.exists() ? snap.data() : null); });
          });
          setUserName(sellerDoc?.name || firebaseUser.email);
          setPage("sales");
        }
      } else {
        setUser(null); setUserRole(null); setUserName(""); setLoading(false);
      }
    });
    return () => unsub();
  }, []);

  // ── Online/offline ─────────────────────────────────────────────
  useEffect(() => {
    const goOnline  = () => { setIsOnline(true);  showToast("🌐 Back online — syncing…", "sync"); };
    const goOffline = () => { setIsOnline(false); showToast("📵 Offline — saved locally, will sync when reconnected", "warn"); };
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => { window.removeEventListener("online", goOnline); window.removeEventListener("offline", goOffline); };
  }, []);

  // ── Firestore listeners (only when logged in) ─────────────────
  useEffect(() => {
    if (!user) return;
    const unsubs = [];
    unsubs.push(onSnapshot(collection(db, "drinks"), snap => {
      setDrinks(snap.docs.map(d => ({ id: d.id, ...d.data() }))); setLoading(false);
    }));
    unsubs.push(onSnapshot(collection(db, "sales"), snap => {
      setSales(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)));
    }));
    unsubs.push(onSnapshot(collection(db, "debts"), snap => {
      setDebts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }));
    unsubs.push(onSnapshot(collection(db, "sellers"), snap => {
      setSellersList(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }));
    return () => unsubs.forEach(u => u());
  }, [user]);

  // ── Logout ─────────────────────────────────────────────────────
  async function handleLogout() { await signOut(auth); setPage("dashboard"); setLoading(true); }

  // ── DRINKS CRUD ──────────────────────────────────────────────
  async function saveDrink() {
    if (!dForm.name || !dForm.buyPrice || !dForm.sellPrice) return;
    const payload = {
      name:       dForm.name,
      category:   dForm.category  || "Water",
      emoji:      dForm.emoji     || "💧",
      buyPrice:   +dForm.buyPrice,
      sellPrice:  +dForm.sellPrice,
      stock:      +dForm.stock    || 0,
      lowAlert:   +dForm.lowAlert || 5,
      updatedAt:  serverTimestamp(),
    };
    try {
      if (editId) {
        await updateDoc(doc(db, "drinks", editId), payload);
        showToast(`${payload.name} updated ✓`);
      } else {
        payload.createdAt = serverTimestamp();
        await addDoc(collection(db, "drinks"), payload);
        showToast(`${payload.name} added ✓`);
      }
      setModal(null);
    } catch (e) { showToast("Save failed: " + e.message, "err"); }
  }

  async function deleteDrink(id) {
    if (!window.confirm("Delete this product?")) return;
    await deleteDoc(doc(db, "drinks", id));
    showToast("Product removed", "warn");
  }

  async function restockDrink(id, qty) {
    const drink = drinks.find(d => d.id === id);
    if (!drink) return;
    await updateDoc(doc(db, "drinks", id), {
      stock:     drink.stock + +qty,
      updatedAt: serverTimestamp(),
    });
    showToast(`Restocked +${qty} packs ✓`);
  }

  // ── SALES ────────────────────────────────────────────────────
  const saleItem   = drinks.find(d => d.id === saleForm.drinkId);
  const saleTotal  = saleItem ? saleItem.sellPrice * +saleForm.packs : 0;
  const saleProfit = saleItem ? (saleItem.sellPrice - saleItem.buyPrice) * +saleForm.packs : 0;

  async function confirmSale() {
    if (!saleItem || +saleForm.packs <= 0) return;
    if (+saleForm.packs > saleItem.stock) { showToast("Not enough stock!", "err"); return; }

    const saleDoc = {
      drinkId:   saleItem.id,
      drinkName: saleItem.name,
      packs:     +saleForm.packs,
      sellPrice: saleItem.sellPrice,
      buyPrice:  saleItem.buyPrice,
      seller:    saleForm.seller,
      customer:  saleForm.customer || "Walk-in",
      paid:      saleForm.paid,
      date:      todayStr(),
      time:      nowStr(),
      createdAt: serverTimestamp(),
    };

    try {
      await Promise.all([
        addDoc(collection(db, "sales"), saleDoc),
        updateDoc(doc(db, "drinks", saleItem.id), {
          stock:     saleItem.stock - +saleForm.packs,
          updatedAt: serverTimestamp(),
        }),
        ...(saleForm.paid ? [] : [
          addDoc(collection(db, "debts"), {
            customer:  saleForm.customer || "Unknown",
            drinkName: saleItem.name,
            packs:     +saleForm.packs,
            amount:    saleTotal,
            seller:    saleForm.seller,
            date:      todayStr(),
            paid:      false,
            createdAt: serverTimestamp(),
          })
        ])
      ]);

      const newStock = saleItem.stock - +saleForm.packs;
      if (newStock <= saleItem.lowAlert) {
        showToast(`⚠️ Low stock: ${saleItem.name} — ${newStock} packs left`, "warn");
      } else {
        showToast(`Sale recorded — ${GHS(saleTotal)}${!isOnline ? " (saved offline, will sync)" : ""}`);
      }

      setSaleForm({ drinkId: "", packs: 1, seller: saleForm.seller, customer: "", paid: true });
      setModal(null);
    } catch (e) { showToast("Error: " + e.message, "err"); }
  }

  // ── DEBTS ────────────────────────────────────────────────────
  async function markDebtPaid(id) {
    await updateDoc(doc(db, "debts", id), { paid: true, paidAt: serverTimestamp() });
    showToast("Debt marked as paid ✓");
  }

  async function addDebt() {
    const d = drinks.find(x => x.id === debtForm.drinkId);
    if (!d || !debtForm.customer) return;
    const amount = d.sellPrice * +debtForm.packs;
    await Promise.all([
      addDoc(collection(db, "debts"), {
        customer:  debtForm.customer,
        drinkName: d.name,
        packs:     +debtForm.packs,
        amount,
        seller:    debtForm.seller,
        date:      todayStr(),
        paid:      false,
        createdAt: serverTimestamp(),
      }),
      updateDoc(doc(db, "drinks", d.id), {
        stock:     d.stock - +debtForm.packs,
        updatedAt: serverTimestamp(),
      }),
    ]);
    showToast(`Debt recorded for ${debtForm.customer}`);
    setDebtForm({ customer: "", drinkId: "", packs: 1, seller: userName });
    setModal(null);
  }

  // ── BACKUP ───────────────────────────────────────────────────
  function exportBackup() {
    const data = { drinks, sales, debts, sellersList, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = `hwds-backup-${todayStr()}.json`; a.click();
    URL.revokeObjectURL(url);
    showToast("Backup downloaded ✓");
  }

  // ── Derived stats ─────────────────────────────────────────────
  const lowItems     = drinks.filter(d => d.stock <= d.lowAlert);
  const todaySales   = sales.filter(s => s.date === todayStr());
  const todayRevenue = todaySales.reduce((a, s) => a + s.packs * s.sellPrice, 0);
  const todayProfit  = todaySales.reduce((a, s) => a + s.packs * (s.sellPrice - s.buyPrice), 0);
  const totalStock   = drinks.reduce((a, d) => a + d.stock, 0);
  const totalDebt    = debts.filter(d => !d.paid).reduce((a, d) => a + d.amount, 0);

  const bestSeller = useMemo(() => {
    const counts = {};
    todaySales.forEach(s => { counts[s.drinkName] = (counts[s.drinkName] || 0) + s.packs; });
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    return top ? { name: top[0], packs: top[1] } : null;
  }, [todaySales]);

  const reportSales = useMemo(() => {
    const now = new Date();
    return sales.filter(s => {
      const d = new Date(s.date);
      if (reportPeriod === "today") return s.date === todayStr();
      if (reportPeriod === "week")  return (now - d) / 86400000 <= 7;
      if (reportPeriod === "month") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      return true;
    });
  }, [sales, reportPeriod]);

  const reportRevenue  = reportSales.reduce((a, s) => a + s.packs * s.sellPrice, 0);
  const reportProfit   = reportSales.reduce((a, s) => a + s.packs * (s.sellPrice - s.buyPrice), 0);
  const reportPacks    = reportSales.reduce((a, s) => a + s.packs, 0);

  const drinkSummary = useMemo(() => {
    const map = {};
    reportSales.forEach(s => {
      if (!map[s.drinkName]) map[s.drinkName] = { name: s.drinkName, packs: 0, revenue: 0, profit: 0 };
      map[s.drinkName].packs   += s.packs;
      map[s.drinkName].revenue += s.packs * s.sellPrice;
      map[s.drinkName].profit  += s.packs * (s.sellPrice - s.buyPrice);
    });
    return Object.values(map).sort((a, b) => b.packs - a.packs);
  }, [reportSales]);

  const sellerSummary = useMemo(() => {
    const map = {};
    reportSales.forEach(s => {
      if (!map[s.seller]) map[s.seller] = { seller: s.seller, packs: 0, revenue: 0 };
      map[s.seller].packs   += s.packs;
      map[s.seller].revenue += s.packs * s.sellPrice;
    });
    return Object.values(map).sort((a, b) => b.revenue - a.revenue);
  }, [reportSales]);

  const filteredDrinks = useMemo(() =>
    drinks.filter(d =>
      (catFilter === "All" || d.category === catFilter) &&
      d.name.toLowerCase().includes(searchQ.toLowerCase())
    ), [drinks, catFilter, searchQ]);

  // ── RENDER ───────────────────────────────────────────────────

  // Still checking auth state
  if (user === undefined) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"100vh", fontFamily:"'DM Sans',sans-serif", flexDirection:"column", gap:14, background:"#f4f6fb" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;800&display=swap" rel="stylesheet" />
      <div style={{ fontSize:48 }}>🏪</div>
      <div style={{ fontSize:18, fontWeight:800, color:"#1e293b" }}>HWDS</div>
      <div style={{ fontSize:13, color:"#64748b" }}>Loading…</div>
      <div style={{ width:40, height:40, border:"3px solid #e2e8f0", borderTopColor:"#1d4ed8", borderRadius:"50%", animation:"spin 0.8s linear infinite" }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  // Not logged in → show login screen
  if (!user) return <LoginScreen />;

  // Loading data after login
  if (loading) return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"100vh", fontFamily:"'DM Sans',sans-serif", flexDirection:"column", gap:14, background:"#f4f6fb" }}>
      <div style={{ fontSize:48 }}>🏪</div>
      <div style={{ fontSize:18, fontWeight:800, color:"#1e293b" }}>Hosny Water & Drink Shop</div>
      <div style={{ fontSize:13, color:"#64748b" }}>Connecting to database…</div>
      <div style={{ width:40, height:40, border:"3px solid #e2e8f0", borderTopColor:"#1d4ed8", borderRadius:"50%", animation:"spin 0.8s linear infinite" }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif", background: "#f4f6fb", minHeight: "100vh", color: "#111827", display: "flex" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@500&display=swap" rel="stylesheet" />
      <style>{`
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:4px;height:4px}
        ::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:4px}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes tIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}

        .sidebar{width:224px;background:#0f172a;flex-shrink:0;display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
        .sb-logo{padding:20px 16px 14px;border-bottom:1px solid #1e293b}
        .sb-logo-title{font-size:16px;font-weight:800;color:#fff;letter-spacing:-.3px;margin-top:4px}
        .sb-logo-sub{font-size:10px;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:.8px;margin-top:2px}
        .sb-nav{padding:10px 8px;flex:1}
        .sb-sec{font-size:10px;font-weight:700;color:#334155;text-transform:uppercase;letter-spacing:.8px;padding:8px 10px 4px}
        .sb-btn{width:100%;background:none;border:none;font-family:inherit;font-size:13px;font-weight:600;color:#94a3b8;padding:9px 12px;border-radius:9px;cursor:pointer;transition:all .15s;display:flex;align-items:center;gap:9px;text-align:left;margin-bottom:2px}
        .sb-btn:hover{background:#1e293b;color:#e2e8f0}
        .sb-btn.on{background:#1d4ed8;color:#fff}
        .nb{background:#ef4444;color:#fff;font-size:10px;font-weight:800;padding:2px 7px;border-radius:20px;margin-left:auto}

        .main{flex:1;min-width:0;display:flex;flex-direction:column}
        .topbar{background:#fff;border-bottom:1px solid #e2e8f0;padding:0 22px;height:56px;display:flex;align-items:center;gap:12px;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px #00000008}
        .topbar-title{font-size:16px;font-weight:800;flex:1}
        .content{padding:20px 22px;flex:1}

        .card{background:#fff;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 1px 4px #0000000a}
        .card-p{padding:20px}
        .stat{background:#fff;border-radius:14px;border:1px solid #e2e8f0;padding:16px 18px}
        .stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;margin-bottom:20px}

        .btn{border:none;border-radius:10px;font-family:inherit;font-weight:700;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;gap:6px;font-size:13px}
        .btn-primary{background:#1d4ed8;color:#fff;padding:10px 20px}
        .btn-primary:hover{background:#1e40af;box-shadow:0 4px 14px #1d4ed830;transform:translateY(-1px)}
        .btn-success{background:#16a34a;color:#fff;padding:10px 20px}
        .btn-success:hover{background:#15803d}
        .btn-outline{background:#fff;border:1.5px solid #e2e8f0;color:#374151;padding:8px 15px;font-size:12px}
        .btn-outline:hover{border-color:#1d4ed8;color:#1d4ed8}
        .btn-soft{background:#eff6ff;color:#1d4ed8;padding:7px 14px;font-size:12px}
        .btn-soft:hover{background:#dbeafe}
        .btn-red{background:#fee2e2;border:1.5px solid #fecaca;color:#b91c1c;padding:7px 13px;font-size:12px}
        .btn-red:hover{background:#fecaca}
        .btn-green{background:#dcfce7;border:1.5px solid #bbf7d0;color:#15803d;padding:7px 13px;font-size:12px}
        .btn-icon{background:#f1f5f9;border:none;width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#64748b;font-size:14px;transition:all .15s;font-family:inherit}
        .btn-icon:hover{background:#e2e8f0;color:#111827}

        input,select,textarea{background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:10px;color:#111827;padding:10px 13px;font-family:inherit;font-size:13px;outline:none;width:100%;transition:all .15s}
        input:focus,select:focus{border-color:#1d4ed8;background:#fff;box-shadow:0 0 0 3px #1d4ed815}
        label{font-size:11px;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;display:block;margin-bottom:5px}

        .badge{font-size:10px;font-weight:800;padding:3px 9px;border-radius:20px;display:inline-block}
        .badge-blue{background:#dbeafe;color:#1e40af}
        .badge-green{background:#dcfce7;color:#166534}
        .badge-yellow{background:#fef3c7;color:#92400e}
        .badge-red{background:#fee2e2;color:#991b1b}
        .badge-gray{background:#f1f5f9;color:#475569}
        .badge-purple{background:#f3e8ff;color:#7e22ce}

        .tbl{width:100%;border-collapse:collapse}
        .tbl th{padding:11px 16px;text-align:left;font-size:10px;font-weight:800;color:#94a3b8;text-transform:uppercase;letter-spacing:.7px;background:#f8fafc;border-bottom:1.5px solid #e2e8f0}
        .tbl td{padding:13px 16px;font-size:13px;border-bottom:1px solid #f1f5f9;vertical-align:middle}
        .tbl tr:last-child td{border-bottom:none}
        .tbl tr:hover td{background:#fafcff}

        .overlay{position:fixed;inset:0;background:#00000060;z-index:600;display:flex;align-items:center;justify-content:center;padding:16px}
        .modal{background:#fff;border-radius:20px;padding:28px;width:460px;max-width:100%;max-height:92vh;overflow-y:auto;box-shadow:0 32px 80px #00000025;animation:fadeIn .2s ease}
        .modal-title{font-size:17px;font-weight:800;margin-bottom:20px}
        .form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
        .form-full{grid-column:1/-1}

        .toast{position:fixed;bottom:24px;right:24px;z-index:9999;padding:13px 20px;border-radius:14px;font-size:13px;font-weight:700;box-shadow:0 8px 28px #00000022;animation:tIn .22s ease;max-width:340px;display:flex;align-items:center;gap:8px}
        .toast-ok{background:#0f172a;color:#fff}
        .toast-warn{background:#d97706;color:#fff}
        .toast-err{background:#dc2626;color:#fff}
        .toast-sync{background:#1d4ed8;color:#fff}

        .pbar{height:6px;background:#e2e8f0;border-radius:4px;overflow:hidden}
        .pbar-fill{height:100%;border-radius:4px;transition:width .5s}
        .sale-total{background:linear-gradient(135deg,#1d4ed8,#4f46e5);color:#fff;border-radius:14px;padding:16px 20px;margin:14px 0}
        .empty{text-align:center;padding:50px 20px;color:#9ca3af}
        .alert-bar{background:#fff7ed;border:1.5px solid #fed7aa;border-radius:12px;padding:12px 16px;display:flex;align-items:center;gap:10px;margin-bottom:16px;flex-wrap:wrap}
        .online-dot{width:8px;height:8px;border-radius:50%;display:inline-block;flex-shrink:0}
      `}</style>

        {/* ── SIDEBAR ── */}
        <aside className="sidebar">
          <div className="sb-logo">
            <div style={{ fontSize:28 }}>🏪</div>
            <div className="sb-logo-title">Hosny Water & Drink Shop</div>
            <div className="sb-logo-sub">HWDS · Pack Manager</div>
            {/* Online/offline dot */}
            <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:10 }}>
              <span style={{ width:8, height:8, borderRadius:"50%", background:isOnline?"#4ade80":"#f87171", boxShadow:isOnline?"0 0 6px #4ade80":"0 0 6px #f87171", display:"inline-block", flexShrink:0 }} />
              <span style={{ fontSize:11, fontWeight:700, color:isOnline?"#4ade80":"#f87171" }}>
                {isOnline ? "Online — Live sync" : "Offline — Saving locally"}
              </span>
            </div>
            {!isOnline && <div style={{ fontSize:10, color:"#475569", marginTop:4, lineHeight:1.4 }}>Will auto-sync when internet returns.</div>}
          </div>

          <div className="sb-nav">
            <div className="sb-sec">Menu</div>
            {/* Owner sees all pages, seller only sees Sales */}
            {(isOwner ? [
              ["dashboard", "📊", "Dashboard"],
              ["stock",     "📦", "Stock / Products"],
              ["sales",     "🛒", "Make a Sale"],
              ["debts",     "📒", "Debts & Credit"],
              ["reports",   "📈", "Reports"],
              ["settings",  "⚙️",  "Settings"],
            ] : [
              ["sales",     "🛒", "Make a Sale"],
            ]).map(([v, ic, lb]) => (
              <button key={v} className={`sb-btn ${page === v ? "on" : ""}`} onClick={() => setPage(v)}>
                <span>{ic}</span> {lb}
                {v === "debts" && debts.filter(d => !d.paid).length > 0 && <span className="nb">{debts.filter(d => !d.paid).length}</span>}
                {v === "stock" && lowItems.length > 0 && <span className="nb">{lowItems.length}</span>}
              </button>
            ))}
          </div>

          {/* User info + logout */}
          <div style={{ padding:"12px 14px", borderTop:"1px solid #1e293b" }}>
            {/* Logged in user */}
            <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
              <div style={{ width:34, height:34, borderRadius:"50%", background:isOwner?"linear-gradient(135deg,#f59e0b,#d97706)":"linear-gradient(135deg,#1d4ed8,#4f46e5)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:15, flexShrink:0 }}>
                {isOwner ? "👑" : "👤"}
              </div>
              <div style={{ minWidth:0 }}>
                <div style={{ fontSize:12, fontWeight:800, color:"#e2e8f0", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{userName}</div>
                <div style={{ fontSize:10, color:isOwner?"#fbbf24":"#93c5fd", fontWeight:700 }}>{isOwner ? "Owner" : "Seller"}</div>
              </div>
            </div>
            {/* Today stats (owner only) */}
            {isOwner && (
              <div style={{ marginBottom:10 }}>
                {[["Revenue", GHS(todayRevenue), "#4ade80"], ["Profit", GHS(todayProfit), "#fbbf24"], ["Debts", GHS(totalDebt), "#f87171"]].map(([l, v, c]) => (
                  <div key={l} style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                    <span style={{ fontSize:11, color:"#64748b" }}>{l}</span>
                    <span style={{ fontSize:11, fontWeight:800, color:c }}>{v}</span>
                  </div>
                ))}
              </div>
            )}
            {/* Logout */}
            <button onClick={handleLogout} style={{ width:"100%", background:"#1e293b", border:"1px solid #334155", borderRadius:9, padding:"8px 0", color:"#94a3b8", fontFamily:"inherit", fontSize:12, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", gap:6, transition:"all .15s" }}
              onMouseEnter={e => e.currentTarget.style.background="#ef444420"}
              onMouseLeave={e => e.currentTarget.style.background="#1e293b"}
            >
              🚪 Sign Out
            </button>
          </div>
        </aside>

      {/* ── MAIN ── */}
      <div className="main">
        <div className="topbar">
          <div className="topbar-title">
            {{ dashboard:"Dashboard", stock:"Stock & Products", sales:"Make a Sale", debts:"Debts & Credit", reports:"Reports", settings:"Settings" }[page]}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, background: isOnline ? "#f0fdf4" : "#fff7ed", border: `1px solid ${isOnline ? "#bbf7d0" : "#fed7aa"}`, borderRadius: 8, padding: "5px 12px" }}>
            <span style={{ fontSize: 12 }}>{isOnline ? "🟢" : "🟡"}</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: isOnline ? "#15803d" : "#d97706" }}>
              {isOnline ? "Firebase connected" : "Offline — will sync"}
            </span>
          </div>
          {page === "stock"   && <button className="btn btn-primary" onClick={() => { setDForm({ name:"", category:"Water", emoji:"💧", buyPrice:"", sellPrice:"", stock:"", lowAlert:5 }); setEditId(null); setModal("drink"); }}>+ Add Product</button>}
          {page === "sales"   && <button className="btn btn-success" onClick={() => { setSaleForm({ drinkId:"", packs:1, seller:sellers[0]||"Owner", customer:"", paid:true }); setModal("sale"); }}>+ New Sale</button>}
          {page === "debts"   && <button className="btn btn-outline" onClick={() => setModal("debt")}>+ Record Debt</button>}
          {page === "reports" && <button className="btn btn-outline" onClick={exportBackup}>⬇️ Export</button>}
        </div>

        <div className="content">

          {/* ═══════════ DASHBOARD ═══════════ */}
          {page === "dashboard" && (
            <div>
              {lowItems.length > 0 && (
                <div className="alert-bar">
                  <span>⚠️</span>
                  <span style={{ fontWeight: 700, color: "#c2410c", fontSize: 13 }}>Low Stock Alert:</span>
                  {lowItems.map(d => <span key={d.id} className="badge badge-yellow">{d.name} — {d.stock} packs</span>)}
                </div>
              )}
              <div className="stat-grid">
                {[
                  { icon:"📦", bg:"#eff6ff", val:`${totalStock}`, sub:"packs in stock",  lbl:"Total Stock",    vc:"#1d4ed8" },
                  { icon:"💰", bg:"#f0fdf4", val:GHS(todayRevenue), sub:`${todaySales.length} sales`, lbl:"Revenue Today", vc:"#15803d" },
                  { icon:"📈", bg:"#fffbeb", val:GHS(todayProfit),  sub:"after buy cost", lbl:"Profit Today",   vc:"#d97706" },
                  { icon:"📒", bg:"#fef2f2", val:GHS(totalDebt),    sub:`${debts.filter(d=>!d.paid).length} customers`, lbl:"Total Debt", vc:"#dc2626" },
                ].map(s => (
                  <div key={s.lbl} className="stat">
                    <div style={{ width:40, height:40, borderRadius:11, background:s.bg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, marginBottom:10 }}>{s.icon}</div>
                    <div style={{ fontSize:22, fontWeight:800, color:s.vc }}>{s.val}</div>
                    <div style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", marginTop:2 }}>{s.lbl}</div>
                    <div style={{ fontSize:11, color:"#9ca3af", marginTop:2 }}>{s.sub}</div>
                  </div>
                ))}
              </div>
              {bestSeller && (
                <div style={{ background:"linear-gradient(135deg,#1d4ed8,#4f46e5)", borderRadius:16, padding:"18px 22px", marginBottom:18, display:"flex", alignItems:"center", gap:16 }}>
                  <div style={{ fontSize:36 }}>🏆</div>
                  <div>
                    <div style={{ fontSize:11, fontWeight:700, color:"#bfdbfe", textTransform:"uppercase", letterSpacing:".6px" }}>Best Seller Today</div>
                    <div style={{ fontSize:20, fontWeight:900, color:"#fff", marginTop:2 }}>{bestSeller.name}</div>
                    <div style={{ fontSize:13, color:"#93c5fd", marginTop:2 }}>{bestSeller.packs} packs sold</div>
                  </div>
                </div>
              )}
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
                <div className="card card-p">
                  <div style={{ fontWeight:800, fontSize:14, marginBottom:14 }}>🕐 Recent Sales</div>
                  {sales.slice(0, 7).map(s => (
                    <div key={s.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 0", borderBottom:"1px solid #f1f5f9" }}>
                      <div>
                        <div style={{ fontWeight:700, fontSize:13 }}>{s.drinkName}</div>
                        <div style={{ fontSize:11, color:"#94a3b8" }}>{s.seller} · {s.time} · {s.customer}</div>
                      </div>
                      <div style={{ textAlign:"right" }}>
                        <div style={{ fontWeight:800, color:"#15803d", fontSize:13 }}>{GHS(s.packs * s.sellPrice)}</div>
                        <div style={{ fontSize:10, color:"#94a3b8" }}>{s.packs} packs</div>
                      </div>
                    </div>
                  ))}
                  {sales.length === 0 && <div className="empty" style={{ padding:"20px 0" }}><div>No sales yet</div></div>}
                </div>
                <div className="card card-p">
                  <div style={{ fontWeight:800, fontSize:14, marginBottom:14 }}>📦 Stock Levels</div>
                  {drinks.map(d => {
                    const pct = Math.min(100, (d.stock / Math.max(d.lowAlert * 6, 1)) * 100);
                    return (
                      <div key={d.id} style={{ marginBottom:12 }}>
                        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4, fontSize:12 }}>
                          <span style={{ fontWeight:700 }}>{d.emoji} {d.name}</span>
                          <span style={{ fontWeight:800, color:d.stock <= d.lowAlert ? "#dc2626" : "#15803d" }}>{d.stock} packs</span>
                        </div>
                        <div className="pbar"><div className="pbar-fill" style={{ width:`${pct}%`, background:pct < 30 ? "#ef4444" : pct < 60 ? "#f59e0b" : "#22c55e" }} /></div>
                      </div>
                    );
                  })}
                  {drinks.length === 0 && <div className="empty" style={{ padding:"20px 0" }}><div>No products yet</div></div>}
                </div>
              </div>
            </div>
          )}

          {/* ═══════════ STOCK ═══════════ */}
          {page === "stock" && (
            <div>
              {lowItems.length > 0 && (
                <div className="alert-bar">
                  <span>⚠️</span><span style={{ fontWeight:700, color:"#c2410c", fontSize:13 }}>Restock needed:</span>
                  {lowItems.map(d => <span key={d.id} className="badge badge-yellow">{d.name} ({d.stock})</span>)}
                </div>
              )}
              <div style={{ display:"flex", gap:8, marginBottom:16, flexWrap:"wrap", alignItems:"center" }}>
                <input placeholder="Search products…" value={searchQ} onChange={e => setSearchQ(e.target.value)} style={{ width:200 }} />
                {CATS.map(c => (
                  <button key={c} onClick={() => setCatFilter(c)} style={{ background:catFilter===c?"#1d4ed8":"#f1f5f9", border:"none", borderRadius:20, padding:"5px 14px", fontSize:12, fontWeight:700, color:catFilter===c?"#fff":"#475569", cursor:"pointer", transition:"all .15s" }}>{c}</button>
                ))}
              </div>
              {filteredDrinks.length === 0
                ? <div className="empty"><div style={{ fontSize:48, marginBottom:12 }}>📦</div><div style={{ fontWeight:700 }}>No products found</div></div>
                : (
                  <div className="card" style={{ overflow:"hidden" }}>
                    <table className="tbl">
                      <thead><tr><th>Product</th><th>Category</th><th>Buy Price</th><th>Sell Price</th><th>Profit/pack</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
                      <tbody>
                        {filteredDrinks.map(d => {
                          const profit = d.sellPrice - d.buyPrice;
                          const margin = d.buyPrice > 0 ? ((profit/d.buyPrice)*100).toFixed(0) : 0;
                          return (
                            <tr key={d.id}>
                              <td><div style={{ display:"flex", alignItems:"center", gap:10 }}><span style={{ fontSize:22 }}>{d.emoji}</span><span style={{ fontWeight:800 }}>{d.name}</span></div></td>
                              <td><span className="badge badge-blue">{d.category}</span></td>
                              <td><span style={{ background:"#fffbeb", border:"1.5px solid #fde68a", borderRadius:8, padding:"4px 10px", fontSize:13, fontWeight:800, color:"#92400e" }}>{GHS(d.buyPrice)}</span></td>
                              <td><span style={{ background:"#f0fdf4", border:"1.5px solid #bbf7d0", borderRadius:8, padding:"4px 10px", fontSize:13, fontWeight:800, color:"#15803d" }}>{GHS(d.sellPrice)}</span></td>
                              <td><span style={{ background:"#eff6ff", borderRadius:8, padding:"4px 10px", fontSize:12, fontWeight:800, color:"#1d4ed8" }}>+{GHS(profit)} ({margin}%)</span></td>
                              <td style={{ fontWeight:900, fontSize:15, color:d.stock===0?"#dc2626":d.stock<=d.lowAlert?"#d97706":"#15803d" }}>{d.stock}</td>
                              <td><span className={`badge ${d.stock===0?"badge-red":d.stock<=d.lowAlert?"badge-yellow":"badge-green"}`}>{d.stock===0?"Out of stock":d.stock<=d.lowAlert?"Low stock":"In stock"}</span></td>
                              <td>
                                <div style={{ display:"flex", gap:6 }}>
                                  <RestockBtn drink={d} onRestock={restockDrink} />
                                  <button className="btn-icon" onClick={() => { setDForm({...d}); setEditId(d.id); setModal("drink"); }}>✏️</button>
                                  <button className="btn-icon" style={{ color:"#ef4444" }} onClick={() => deleteDrink(d.id)}>🗑</button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
            </div>
          )}

          {/* ═══════════ SALES ═══════════ */}
          {page === "sales" && (
            <div>
              <div className="stat-grid">
                {[
                  { lbl:"Packs Sold Today", val:todaySales.reduce((a,s)=>a+s.packs,0), icon:"📦", color:"#1d4ed8" },
                  { lbl:"Revenue Today",    val:GHS(todayRevenue), icon:"💰", color:"#15803d" },
                  { lbl:"Profit Today",     val:GHS(todayProfit),  icon:"📈", color:"#d97706" },
                  { lbl:"Transactions",     val:todaySales.length, icon:"🧾", color:"#7c3aed" },
                ].map(s => (
                  <div key={s.lbl} className="stat" style={{ padding:"14px 16px" }}>
                    <div style={{ fontSize:20, marginBottom:6 }}>{s.icon}</div>
                    <div style={{ fontSize:18, fontWeight:900, color:s.color }}>{s.val}</div>
                    <div style={{ fontSize:10, fontWeight:700, color:"#9ca3af", textTransform:"uppercase", letterSpacing:".5px", marginTop:3 }}>{s.lbl}</div>
                  </div>
                ))}
              </div>
              <div className="card" style={{ overflow:"hidden" }}>
                <div style={{ padding:"14px 20px 10px", display:"flex", justifyContent:"space-between", alignItems:"center", borderBottom:"1px solid #f1f5f9" }}>
                  <span style={{ fontWeight:800, fontSize:14 }}>Today's Sales Log</span>
                  <button className="btn btn-success" style={{ padding:"8px 16px", fontSize:12 }} onClick={() => { setSaleForm({ drinkId:"", packs:1, seller:sellers[0]||"Owner", customer:"", paid:true }); setModal("sale"); }}>+ New Sale</button>
                </div>
                {todaySales.length === 0
                  ? <div className="empty"><div style={{ fontSize:40, marginBottom:8 }}>🛒</div><div style={{ fontWeight:700 }}>No sales today yet</div></div>
                  : (
                    <table className="tbl">
                      <thead><tr><th>Time</th><th>Product</th><th>Seller</th><th>Customer</th><th>Packs</th><th>Total</th><th>Profit</th><th>Payment</th></tr></thead>
                      <tbody>
                        {todaySales.map(s => (
                          <tr key={s.id}>
                            <td style={{ fontFamily:"'DM Mono',monospace", fontSize:12, color:"#6b7280" }}>{s.time}</td>
                            <td style={{ fontWeight:700 }}>{s.drinkName}</td>
                            <td><span className="badge badge-purple">{s.seller}</span></td>
                            <td style={{ color:"#6b7280" }}>{s.customer}</td>
                            <td style={{ fontWeight:800 }}>{s.packs}</td>
                            <td style={{ fontWeight:800, color:"#15803d" }}>{GHS(s.packs*s.sellPrice)}</td>
                            <td style={{ fontWeight:800, color:"#d97706" }}>+{GHS(s.packs*(s.sellPrice-s.buyPrice))}</td>
                            <td><span className={`badge ${s.paid?"badge-green":"badge-red"}`}>{s.paid?"Paid":"Credit"}</span></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
              </div>
            </div>
          )}

          {/* ═══════════ DEBTS ═══════════ */}
          {page === "debts" && (
            <div>
              <div className="stat-grid">
                <div className="stat"><div style={{ fontSize:36, marginBottom:8 }}>💸</div><div style={{ fontSize:22, fontWeight:800, color:"#dc2626" }}>{GHS(totalDebt)}</div><div style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", marginTop:2 }}>Total Owed</div></div>
                <div className="stat"><div style={{ fontSize:36, marginBottom:8 }}>👥</div><div style={{ fontSize:22, fontWeight:800, color:"#d97706" }}>{debts.filter(d=>!d.paid).length}</div><div style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", marginTop:2 }}>Customers in Debt</div></div>
                <div className="stat"><div style={{ fontSize:36, marginBottom:8 }}>✅</div><div style={{ fontSize:22, fontWeight:800, color:"#15803d" }}>{GHS(debts.filter(d=>d.paid).reduce((a,d)=>a+d.amount,0))}</div><div style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", marginTop:2 }}>Recovered</div></div>
              </div>
              <div className="card" style={{ overflow:"hidden" }}>
                <div style={{ padding:"14px 20px 10px", borderBottom:"1px solid #f1f5f9", fontWeight:800, fontSize:14 }}>📒 Debt Records</div>
                {debts.length === 0
                  ? <div className="empty"><div style={{ fontSize:40, marginBottom:8 }}>✅</div><div style={{ fontWeight:700 }}>No debts recorded</div></div>
                  : (
                    <table className="tbl">
                      <thead><tr><th>Customer</th><th>Product</th><th>Packs</th><th>Amount</th><th>Date</th><th>Seller</th><th>Status</th><th>Action</th></tr></thead>
                      <tbody>
                        {debts.map(d => (
                          <tr key={d.id}>
                            <td style={{ fontWeight:800 }}>{d.customer}</td>
                            <td>{d.drinkName}</td>
                            <td style={{ fontWeight:700 }}>{d.packs}</td>
                            <td style={{ fontWeight:800, color:d.paid?"#15803d":"#dc2626" }}>{GHS(d.amount)}</td>
                            <td style={{ color:"#6b7280", fontSize:12 }}>{dateFmt(d.date)}</td>
                            <td><span className="badge badge-purple">{d.seller}</span></td>
                            <td><span className={`badge ${d.paid?"badge-green":"badge-red"}`}>{d.paid?"Paid":"Owes"}</span></td>
                            <td>{!d.paid && <button className="btn btn-green" style={{ fontSize:12, padding:"6px 14px" }} onClick={() => markDebtPaid(d.id)}>Mark Paid</button>}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
              </div>
            </div>
          )}

          {/* ═══════════ REPORTS ═══════════ */}
          {page === "reports" && (
            <div>
              <div style={{ display:"flex", gap:8, marginBottom:20 }}>
                {[["today","Today"],["week","This Week"],["month","This Month"],["all","All Time"]].map(([v,lb]) => (
                  <button key={v} onClick={() => setReportPeriod(v)} style={{ background:reportPeriod===v?"#1d4ed8":"#fff", border:reportPeriod===v?"none":"1.5px solid #e2e8f0", borderRadius:10, padding:"9px 20px", fontSize:13, fontWeight:700, color:reportPeriod===v?"#fff":"#374151", cursor:"pointer", transition:"all .15s" }}>{lb}</button>
                ))}
              </div>
              <div className="stat-grid" style={{ marginBottom:20 }}>
                {[
                  { icon:"💰", bg:"#f0fdf4", val:GHS(reportRevenue), lbl:"Revenue",      vc:"#15803d" },
                  { icon:"📈", bg:"#fffbeb", val:GHS(reportProfit),  lbl:"Profit",       vc:"#d97706" },
                  { icon:"📦", bg:"#eff6ff", val:`${reportPacks}`,   lbl:"Packs Sold",   vc:"#1d4ed8" },
                  { icon:"🧾", bg:"#faf5ff", val:reportSales.length, lbl:"Transactions", vc:"#7c3aed" },
                ].map(s => (
                  <div key={s.lbl} className="stat">
                    <div style={{ width:40, height:40, borderRadius:11, background:s.bg, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18, marginBottom:10 }}>{s.icon}</div>
                    <div style={{ fontSize:22, fontWeight:800, color:s.vc }}>{s.val}</div>
                    <div style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", marginTop:2 }}>{s.lbl}</div>
                  </div>
                ))}
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18, marginBottom:18 }}>
                <div className="card card-p">
                  <div style={{ fontWeight:800, fontSize:14, marginBottom:14 }}>🏆 Sales by Product</div>
                  {drinkSummary.length === 0
                    ? <div className="empty" style={{ padding:"20px 0" }}><div>No sales in period</div></div>
                    : drinkSummary.map((d,i) => (
                      <div key={d.name} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 0", borderBottom:"1px solid #f1f5f9" }}>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          <span style={{ background:i===0?"#fef3c7":"#f1f5f9", color:i===0?"#d97706":"#64748b", width:24, height:24, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:800 }}>{i+1}</span>
                          <span style={{ fontWeight:700, fontSize:13 }}>{d.name}</span>
                        </div>
                        <div style={{ textAlign:"right" }}>
                          <div style={{ fontWeight:800, fontSize:13, color:"#15803d" }}>{GHS(d.revenue)}</div>
                          <div style={{ fontSize:11, color:"#94a3b8" }}>{d.packs} packs · +{GHS(d.profit)}</div>
                        </div>
                      </div>
                    ))}
                </div>
                <div className="card card-p">
                  <div style={{ fontWeight:800, fontSize:14, marginBottom:14 }}>👤 Sales by Seller</div>
                  {sellerSummary.length === 0
                    ? <div className="empty" style={{ padding:"20px 0" }}><div>No sales in period</div></div>
                    : sellerSummary.map(s => (
                      <div key={s.seller} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 0", borderBottom:"1px solid #f1f5f9" }}>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          <span style={{ fontSize:20 }}>👤</span><span style={{ fontWeight:700 }}>{s.seller}</span>
                        </div>
                        <div style={{ textAlign:"right" }}>
                          <div style={{ fontWeight:800, color:"#1d4ed8" }}>{GHS(s.revenue)}</div>
                          <div style={{ fontSize:11, color:"#94a3b8" }}>{s.packs} packs</div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
              <div className="card" style={{ overflow:"hidden" }}>
                <div style={{ padding:"14px 20px 10px", borderBottom:"1px solid #f1f5f9", fontWeight:800, fontSize:14 }}>📋 Transaction Log</div>
                {reportSales.length === 0
                  ? <div className="empty"><div>No transactions</div></div>
                  : (
                    <table className="tbl">
                      <thead><tr><th>Date</th><th>Time</th><th>Product</th><th>Seller</th><th>Customer</th><th>Packs</th><th>Total</th><th>Profit</th><th>Pay</th></tr></thead>
                      <tbody>
                        {reportSales.map(s => (
                          <tr key={s.id}>
                            <td style={{ fontSize:12, color:"#6b7280" }}>{dateFmt(s.date)}</td>
                            <td style={{ fontFamily:"'DM Mono',monospace", fontSize:12, color:"#6b7280" }}>{s.time}</td>
                            <td style={{ fontWeight:700 }}>{s.drinkName}</td>
                            <td><span className="badge badge-purple">{s.seller}</span></td>
                            <td style={{ color:"#6b7280" }}>{s.customer}</td>
                            <td style={{ fontWeight:800 }}>{s.packs}</td>
                            <td style={{ fontWeight:800, color:"#15803d" }}>{GHS(s.packs*s.sellPrice)}</td>
                            <td style={{ fontWeight:800, color:"#d97706" }}>+{GHS(s.packs*(s.sellPrice-s.buyPrice))}</td>
                            <td><span className={`badge ${s.paid?"badge-green":"badge-red"}`}>{s.paid?"Paid":"Credit"}</span></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
              </div>
            </div>
          )}

          {/* ═══════════ SETTINGS (Owner only) ═══════════ */}
          {page === "settings" && isOwner && (
            <div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
                {/* Connection status */}
                <div className="card card-p" style={{ gridColumn:"1/-1", background:isOnline?"linear-gradient(135deg,#052e16,#14532d)":"linear-gradient(135deg,#1c1917,#292524)", border:`1.5px solid ${isOnline?"#166534":"#57534e"}` }}>
                  <div style={{ display:"flex", alignItems:"center", gap:16 }}>
                    <div style={{ fontSize:36 }}>{isOnline?"🌐":"📵"}</div>
                    <div>
                      <div style={{ fontSize:16, fontWeight:800, color:"#fff" }}>{isOnline?"Connected to Firebase":"Offline Mode Active"}</div>
                      <div style={{ fontSize:13, color:isOnline?"#86efac":"#a8a29e", marginTop:3 }}>
                        {isOnline
                          ? "All data syncs in real-time. All devices see the same data instantly."
                          : "No internet. All changes saved on this device and will automatically upload to Firebase when internet returns."}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sellers list */}
                <div className="card card-p">
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                    <div style={{ fontWeight:800, fontSize:15 }}>👥 Sellers</div>
                    <button className="btn btn-primary" style={{ padding:"7px 14px", fontSize:12 }} onClick={() => setShowAddSeller(true)}>+ Add Seller</button>
                  </div>
                  <div style={{ fontSize:12, color:"#6b7280", marginBottom:16 }}>Each seller has their own email and password to log in.</div>
                  {sellersList.length === 0
                    ? <div style={{ textAlign:"center", padding:"20px 0", color:"#9ca3af", fontSize:13 }}>No sellers added yet</div>
                    : sellersList.map(s => (
                      <div key={s.id} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 0", borderBottom:"1px solid #f1f5f9" }}>
                        <div style={{ width:36, height:36, borderRadius:"50%", background:"linear-gradient(135deg,#1d4ed8,#4f46e5)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>👤</div>
                        <div style={{ flex:1 }}>
                          <div style={{ fontWeight:700, fontSize:13 }}>{s.name}</div>
                          <div style={{ fontSize:11, color:"#94a3b8" }}>{s.email}</div>
                        </div>
                        <span className="badge badge-blue">Seller</span>
                      </div>
                    ))
                  }
                </div>

                {/* Backup */}
                <div className="card card-p">
                  <div style={{ fontWeight:800, fontSize:15, marginBottom:4 }}>💾 Backup Data</div>
                  <div style={{ fontSize:12, color:"#6b7280", marginBottom:14 }}>Download all data as a file. Send to WhatsApp or Google Drive for safety.</div>
                  <button className="btn btn-primary" style={{ width:"100%", justifyContent:"center", padding:"12px 0", marginBottom:10 }} onClick={exportBackup}>⬇️ Download Backup</button>
                  <div style={{ background:"#f8fafc", border:"1px solid #e2e8f0", borderRadius:10, padding:"10px 14px", fontSize:12, color:"#6b7280" }}>
                    💡 Your data is already safe in Firebase. This is an extra copy.
                  </div>
                </div>

                {/* Data summary */}
                <div className="card card-p" style={{ gridColumn:"1/-1" }}>
                  <div style={{ fontWeight:800, fontSize:15, marginBottom:14 }}>📊 Data Summary</div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))", gap:12 }}>
                    {[
                      { icon:"📦", label:"Products",     count:drinks.length,  color:"#1d4ed8" },
                      { icon:"🧾", label:"Sales Records", count:sales.length,   color:"#15803d" },
                      { icon:"📒", label:"Debt Records",  count:debts.length,   color:"#dc2626" },
                      { icon:"👤", label:"Sellers",       count:sellersList.length, color:"#7c3aed" },
                    ].map(r => (
                      <div key={r.label} style={{ background:"#f8fafc", border:"1px solid #e2e8f0", borderRadius:12, padding:"14px 16px", textAlign:"center" }}>
                        <div style={{ fontSize:28, marginBottom:6 }}>{r.icon}</div>
                        <div style={{ fontSize:22, fontWeight:900, color:r.color }}>{r.count}</div>
                        <div style={{ fontSize:11, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:".5px", marginTop:2 }}>{r.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* How offline works */}
                <div className="card card-p" style={{ gridColumn:"1/-1" }}>
                  <div style={{ fontWeight:800, fontSize:15, marginBottom:14 }}>🔄 How Offline Sync Works</div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))", gap:12 }}>
                    {[
                      { icon:"📵", title:"No Internet",    desc:"Seller records a sale. App saves it instantly on the phone." },
                      { icon:"💾", title:"Stored Locally", desc:"Data is kept safely in the phone memory. Nothing is lost." },
                      { icon:"🌐", title:"Internet Returns",desc:"Firebase automatically detects the connection is back." },
                      { icon:"☁️", title:"Auto Upload",    desc:"All offline sales upload to Firebase instantly — no action needed." },
                      { icon:"📱", title:"Owner Sees It",  desc:"Owner's phone receives the update in real-time." },
                      { icon:"✅", title:"All Synced",     desc:"Every phone shows the same live data." },
                    ].map(c => (
                      <div key={c.title} style={{ background:"#f8fafc", border:"1px solid #e2e8f0", borderRadius:12, padding:"14px 16px" }}>
                        <div style={{ fontSize:24, marginBottom:8 }}>{c.icon}</div>
                        <div style={{ fontWeight:800, fontSize:13, marginBottom:4 }}>{c.title}</div>
                        <div style={{ fontSize:12, color:"#6b7280", lineHeight:1.5 }}>{c.desc}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ═══════════ MODALS ═══════════ */}
      {modal === "drink" && (
        <div className="overlay" onClick={e => e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-title">{editId?"✏️ Edit Product":"📦 Add New Product"}</div>
            <div className="form-row">
              <div className="form-full"><label>Product / Brand Name</label><input type="text" placeholder="e.g. Voltic Water, Coca-Cola…" value={dForm.name||""} onChange={e=>setDForm(f=>({...f,name:e.target.value}))} autoFocus /></div>
              <div><label>Category</label><select value={dForm.category||"Water"} onChange={e=>setDForm(f=>({...f,category:e.target.value}))}>{CATS.filter(c=>c!=="All").map(c=><option key={c}>{c}</option>)}</select></div>
              <div><label>Emoji</label><input type="text" placeholder="💧" value={dForm.emoji||""} onChange={e=>setDForm(f=>({...f,emoji:e.target.value}))} /></div>
              <div><label>Buy Price per Pack (GH₵)</label><input type="number" step="0.01" placeholder="0.00" value={dForm.buyPrice||""} onChange={e=>setDForm(f=>({...f,buyPrice:e.target.value}))} /></div>
              <div><label>Sell Price per Pack (GH₵)</label><input type="number" step="0.01" placeholder="0.00" value={dForm.sellPrice||""} onChange={e=>setDForm(f=>({...f,sellPrice:e.target.value}))} /></div>
              <div><label>Packs in Stock</label><input type="number" placeholder="0" value={dForm.stock||""} onChange={e=>setDForm(f=>({...f,stock:e.target.value}))} /></div>
              <div><label>Low Stock Alert (packs)</label><input type="number" placeholder="5" value={dForm.lowAlert||""} onChange={e=>setDForm(f=>({...f,lowAlert:e.target.value}))} /></div>
              {dForm.buyPrice&&dForm.sellPrice&&(
                <div className="form-full">
                  {+dForm.sellPrice>+dForm.buyPrice
                    ?<div style={{background:"#f0fdf4",border:"1.5px solid #bbf7d0",borderRadius:10,padding:"10px 14px",fontSize:13,fontWeight:700,color:"#15803d"}}>✅ Profit: {GHS(+dForm.sellPrice-+dForm.buyPrice)} per pack ({((+dForm.sellPrice-+dForm.buyPrice)/+dForm.buyPrice*100).toFixed(1)}% margin)</div>
                    :<div style={{background:"#fff7ed",border:"1.5px solid #fed7aa",borderRadius:10,padding:"10px 14px",fontSize:13,fontWeight:700,color:"#c2410c"}}>⚠️ Sell price must be higher than buy price!</div>
                  }
                </div>
              )}
            </div>
            <div style={{display:"flex",gap:10,marginTop:22,justifyContent:"flex-end"}}>
              <button className="btn btn-outline" onClick={()=>setModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={saveDrink}>{editId?"Save Changes":"Add Product"}</button>
            </div>
          </div>
        </div>
      )}

      {modal === "sale" && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-title">🛒 Record a Sale</div>
            <div className="form-row">
              <div className="form-full"><label>Product</label><select value={saleForm.drinkId} onChange={e=>setSaleForm(f=>({...f,drinkId:e.target.value}))}><option value="">-- Select drink --</option>{drinks.map(d=><option key={d.id} value={d.id}>{d.emoji} {d.name} — {d.stock} packs left</option>)}</select></div>
              <div><label>Number of Packs</label><input type="number" min="1" value={saleForm.packs} onChange={e=>setSaleForm(f=>({...f,packs:e.target.value}))} /></div>
              <div><label>Seller Name</label><select value={saleForm.seller} onChange={e=>setSaleForm(f=>({...f,seller:e.target.value}))}>
                <option value={userName}>{userName} (You)</option>
                {sellersList.filter(s => s.email !== user?.email).map(s=><option key={s.id} value={s.name}>{s.name}</option>)}
              </select></div>
              <div className="form-full"><label>Customer Name (optional)</label><input type="text" placeholder="Walk-in / Customer name…" value={saleForm.customer} onChange={e=>setSaleForm(f=>({...f,customer:e.target.value}))} /></div>
              <div className="form-full">
                <label>Payment</label>
                <div style={{display:"flex",gap:8}}>
                  {[true,false].map(v=>(
                    <button key={String(v)} onClick={()=>setSaleForm(f=>({...f,paid:v}))} style={{flex:1,padding:"10px 0",borderRadius:10,border:saleForm.paid===v?"none":"1.5px solid #e2e8f0",background:saleForm.paid===v?(v?"#15803d":"#dc2626"):"#f8fafc",color:saleForm.paid===v?"#fff":"#374151",fontWeight:700,cursor:"pointer",fontSize:13,transition:"all .15s"}}>
                      {v?"✅ Paid Now":"📒 Pay Later (Credit)"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            {saleItem&&+saleForm.packs>0&&(
              <div className="sale-total">
                <div style={{fontSize:12,fontWeight:700,color:"#93c5fd",marginBottom:4}}>{saleForm.packs} packs × {GHS(saleItem.sellPrice)}</div>
                <div style={{fontSize:26,fontWeight:900}}>{GHS(saleTotal)}</div>
                <div style={{fontSize:12,color:"#93c5fd",marginTop:4}}>
                  Profit: +{GHS(saleProfit)} · {saleItem.stock-+saleForm.packs>=0?`${saleItem.stock-+saleForm.packs} packs remaining`:"⚠️ Not enough stock!"}
                  {!isOnline&&" · 📵 Will sync when online"}
                </div>
              </div>
            )}
            <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
              <button className="btn btn-outline" onClick={()=>setModal(null)}>Cancel</button>
              <button className="btn btn-success" onClick={confirmSale} disabled={!saleItem||+saleForm.packs<=0||+saleForm.packs>(saleItem?.stock||0)}>Confirm Sale</button>
            </div>
          </div>
        </div>
      )}

      {modal === "debt" && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
          <div className="modal">
            <div className="modal-title">📒 Record a Debt</div>
            <div className="form-row">
              <div className="form-full"><label>Customer Name</label><input type="text" placeholder="e.g. Kwame Asante" value={debtForm.customer} onChange={e=>setDebtForm(f=>({...f,customer:e.target.value}))} autoFocus /></div>
              <div className="form-full"><label>Product Taken</label><select value={debtForm.drinkId} onChange={e=>setDebtForm(f=>({...f,drinkId:e.target.value}))}><option value="">-- Select drink --</option>{drinks.map(d=><option key={d.id} value={d.id}>{d.emoji} {d.name} — {d.stock} packs left</option>)}</select></div>
              <div><label>Packs Taken</label><input type="number" min="1" value={debtForm.packs} onChange={e=>setDebtForm(f=>({...f,packs:e.target.value}))} /></div>
              <div><label>Recorded By</label><select value={debtForm.seller} onChange={e=>setDebtForm(f=>({...f,seller:e.target.value}))}>
                <option value={userName}>{userName} (You)</option>
                {sellersList.filter(s => s.email !== user?.email).map(s=><option key={s.id} value={s.name}>{s.name}</option>)}
              </select></div>
            </div>
            {debtForm.drinkId&&+debtForm.packs>0&&(()=>{const d=drinks.find(x=>x.id===debtForm.drinkId);return d?<div style={{background:"#fef2f2",border:"1.5px solid #fecaca",borderRadius:10,padding:"10px 14px",margin:"14px 0",fontWeight:700,color:"#dc2626"}}>Amount owed: {GHS(d.sellPrice*+debtForm.packs)}</div>:null;})()}
            <div style={{display:"flex",gap:10,justifyContent:"flex-end",marginTop:16}}>
              <button className="btn btn-outline" onClick={()=>setModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={addDebt}>Record Debt</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Seller Modal */}
      {showAddSeller && (
        <AddSellerModal
          onClose={() => setShowAddSeller(false)}
          onAdded={(name) => showToast(`Seller "${name}" added successfully ✓`)}
        />
      )}

      {toast && <div className={`toast toast-${toast.type}`}>{toast.msg}</div>}
    </div>
  );
}

function RestockBtn({ drink, onRestock }) {
  const [open, setOpen] = useState(false);
  const [qty, setQty]   = useState("");
  if (!open) return <button className="btn btn-soft" style={{fontSize:11,padding:"6px 12px"}} onClick={()=>setOpen(true)}>+ Restock</button>;
  return (
    <div style={{display:"flex",gap:4,alignItems:"center"}}>
      <input type="number" value={qty} onChange={e=>setQty(e.target.value)} placeholder="packs" style={{width:68,padding:"6px 8px",fontSize:12}} autoFocus />
      <button className="btn btn-success" style={{padding:"6px 10px",fontSize:12}} onClick={()=>{if(+qty>0){onRestock(drink.id,qty);setOpen(false);setQty("");}}}> ✓</button>
      <button className="btn-icon" onClick={()=>setOpen(false)}>✕</button>
    </div>
  );
}
